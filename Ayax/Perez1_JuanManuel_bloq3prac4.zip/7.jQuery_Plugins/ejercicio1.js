$(document).ready(function(){
    $("button").on("click",function(){
        $("p").desaparece()
    })
})