$(document).ready(function(){
    $("button").on("click",function(){
        $("p").crecer()
    })
})