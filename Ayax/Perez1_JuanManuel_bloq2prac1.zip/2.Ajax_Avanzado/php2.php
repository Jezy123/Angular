<?php
    $email=$_POST["envioEmail"];
            echo ("¡Hola, este es tu correo!" . $email);
        ?>