<?php
            echo ("¡Hola, soy un script de PHP!");
        ?>