$(document).ready(function(){

    $("#mostrar").click(function(){
        $("img").show(2500) 
    });

    $("#ocultar").click(function(){
        $("img").hide("slow")
    });

})