$(document).ready(function(){

    $("div").mouseover(function(){
        $("div").css("color","green")
        alert($("div").length)
    });

})