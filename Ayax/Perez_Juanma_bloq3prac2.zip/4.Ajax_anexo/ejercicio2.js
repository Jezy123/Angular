$(document).ready(function(){

    $("#boton").on("click",function(){
        
        $("#contenido").load("ejemplo.html",async function(){
            alert("Cargado")
        })
     
    })
})

