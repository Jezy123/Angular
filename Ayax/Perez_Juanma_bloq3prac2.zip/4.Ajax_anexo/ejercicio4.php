<?php
    $name=$_POST["name"];
            echo ("¡Hola, este es tu nombre " . $name);
?>