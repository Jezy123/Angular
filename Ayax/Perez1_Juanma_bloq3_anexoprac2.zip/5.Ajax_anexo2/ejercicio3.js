$(document).ready(function(){

    $("#boton").on("click",function(){
        $.getScript( "js.js" )
     
    })
})

