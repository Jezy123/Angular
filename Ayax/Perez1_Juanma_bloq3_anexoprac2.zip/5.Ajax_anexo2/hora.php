<?php
echo ('Ahora:            '. date('Y-m-d') ."\n")
?>